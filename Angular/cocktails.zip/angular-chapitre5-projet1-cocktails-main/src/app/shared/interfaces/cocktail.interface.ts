export interface Cocktail {
  imageUrl: string;
  name: string;
  description: string;
}
